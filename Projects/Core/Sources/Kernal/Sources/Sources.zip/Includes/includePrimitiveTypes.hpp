#pragma once

#include "../Modules/NEInteger/NEInteger.hpp"
#include "../Modules/NEFloat/NEFloat.hpp"