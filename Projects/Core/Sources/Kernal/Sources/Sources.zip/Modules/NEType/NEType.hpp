#pragma once

#include "../NEUnit/NEUnit.hpp"

namespace NE
{
	class NE_DLL NEType : public NEUnit
	{

	};
}