#include "NEClassBaseList.hpp"

namespace NE
{
	NEClassBaseList::NEClassBaseList()
		: Super()
	{

	}

	NEClassBaseList::NEClassBaseList(const NEClassBaseList& rhs)
		: Super(rhs)
	{

	}

	NEClassBaseList::~NEClassBaseList()
	{

	}
}