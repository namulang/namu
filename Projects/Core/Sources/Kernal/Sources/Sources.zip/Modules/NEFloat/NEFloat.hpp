#pragma once

#include "../NENumericType/NENumericType.hpp"

namespace NE
{
	class NE_DLL NEFloat : public NENumericType
	{

	};
}