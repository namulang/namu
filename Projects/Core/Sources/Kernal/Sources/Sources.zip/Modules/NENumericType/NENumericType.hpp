#pragma once

#include "../NEType/NEType.hpp"

namespace NE
{
	class NE_DLL NENumericType : public NEType
	{

	};
}