#include "CCamera.hpp"

CCamera::CCamera() 
: _x(0.0f), _y(0.0f), _z(0.0f), _angle(0.0f), _scale_x(1.0f), _scale_y(1.0f)
{/*serialize_load*/}
CCamera::CCamera(float x, float y, float z, float angle, float scale_x, float scale_y) 
: _x(x), _y(y), _z(z), _angle(angle), _scale_x(scale_x), _scale_y(scale_y), _render_state(DEFAULT_CENGINE_RENDERSTATE_PASS)
{}
//	�Ҹ���:
CCamera::~CCamera()
{}
//	Ȱ��ȭ�� ���Ͱ� �ϳ��� �ִ��� �˻��Ѵ�
bool	CCamera::isThereEnabledFilter()
{
	if (!_blur_data._enable &&
		!_gauss_data._enable)
		return false;
	else
		return true;
}